package com.neumont.csc150.Model;

public class Player {

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		if (name == null || name.length() == 0) {
			throw new IllegalArgumentException("name cannot be null or empty.");
		}
		this.name = name;
	}

	@Override
	public boolean equals(Object obj) {
		Player play = (Player) obj;
		return (this.getName().equals(play.getName()));
	}

	@Override
	public String toString() {
		return this.getName();

	}

	public Player() {

	}

	public Player(String name) {

	}

}
