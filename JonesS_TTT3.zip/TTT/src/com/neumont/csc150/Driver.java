package com.neumont.csc150;

import com.neumont.csc150.model.Board;

public class Driver {

	public static void main(String[] args) {
		Board board = new Board();
		board.formBoard();
	}

}
