package com.neumont.csc150.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import com.neumont.csc150.controller.BossMan;
import com.neumont.csc150.model.Player;

public class GUI {

	private JFrame mainWindow;
	private JPanel mainPanel;
	private JMenuBar menuBar;
	private JMenu menu;
	private JMenuItem newGameMI, saveGameMI, loadGameMI;
	private int lastMenuSelection;
	
	public GUI() {
		mainWindow = new JFrame("Tic-Tac-Toe");
		mainPanel = new JPanel();
		mainWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.initMenu();
		mainWindow.setLocationRelativeTo(null);
		mainWindow.getContentPane().add(mainPanel);
		mainWindow.setVisible(true);
		mainWindow.setSize(500, 500);
		mainWindow.setLocationRelativeTo(null);
	}
	
	private void initMenu() {
		this.menuBar = new JMenuBar();
		this.menu = new JMenu("Options");
		this.newGameMI = new JMenuItem("New Game");
		this.saveGameMI = new JMenuItem("Save Game");
		this.loadGameMI = new JMenuItem("Load Game");
		this.menu.add(this.newGameMI);
		this.menu.add(this.saveGameMI);
		this.menu.add(this.loadGameMI);
		this.newGameMI.addActionListener((ActionListener) this);
		this.saveGameMI.addActionListener((ActionListener) this);
		this.loadGameMI.addActionListener((ActionListener) this);
		this.menuBar.add(this.menu);
		this.mainWindow.setJMenuBar(this.menuBar);
	}

	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == this.newGameMI) {
			JOptionPane.showMessageDialog(this.mainWindow, "You have begun a new game");
			lastMenuSelection = BossMan.NEW_GAME;
		}
		else if(e.getSource() == this.saveGameMI) {
			JOptionPane.showMessageDialog(this.mainWindow, "Game saved");
			lastMenuSelection = BossMan.SAVE_GAME;
		}
		else if(e.getSource() == this.loadGameMI) {
			JOptionPane.showMessageDialog(this.mainWindow, "Game loaded");
			lastMenuSelection = BossMan.LOAD_GAME;
		}
		else {
			throw new RuntimeException("Unrecognizable action source: " + e.getSource());
		}
	}

	public void displayMenu() {}

	public int getMenuSelection() {
		if(lastMenuSelection == 0) {
			throw new RuntimeException("No selection made");
		}
		return lastMenuSelection;
	}

	public String promptForPlayerName() {
		String rawInput = null;
		boolean isGood = false;
		while(!isGood) {
			rawInput = JOptionPane.showInputDialog(this.mainWindow, "Please enter player name: ");
			
			if(rawInput == null || rawInput.length() == 0) {
				JOptionPane.showMessageDialog(this.mainWindow, "Must enter a name");
			}
			else {
				isGood = true;
			}
		}
		return rawInput;
	}

	public void displayPlayers(ArrayList<Player> players) {
		// TODO Auto-generated method stub
		
	}
}
