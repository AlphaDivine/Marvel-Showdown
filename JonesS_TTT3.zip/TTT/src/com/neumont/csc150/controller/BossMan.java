package com.neumont.csc150.controller;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import com.neumont.csc150.model.Player;
import com.neumont.csc150.view.GUI;

public class BossMan {

	public static final int NEW_GAME = 1;
	public static final int SAVE_GAME = 2;
	public static final int LOAD_GAME = 3;
	public static final int EXIT = 4;
	private GUI gui = new GUI();
	boolean accepted = false;
	boolean complete = false;
	
	public void setupGame() throws IOException {
		boolean setupComplete = false;
		while(!setupComplete) {
			this.gui.displayMenu();
			int selection = this.gui.getMenuSelection();
			switch(selection) {
			case NEW_GAME:
				this.newGame();
				break;
			case LOAD_GAME:
				this.loadGame(null);
				break;
			case SAVE_GAME:
				this.saveGame(null, null);
				break;
			case EXIT:
				break;
			default:
				throw new RuntimeException("Not a valid option.");
			}
		}
	}
	
	public void newGame() throws IOException {
		setupGame();
	}
	
	public void saveGame(String filePath, String data) throws FileNotFoundException{
		OutputStream outFile = new FileOutputStream(filePath);
		PrintWriter out = new PrintWriter(outFile);
		out.println(data);
		out.close();
	}
	
	public String loadGame(String filePath) throws IOException{
		InputStream inStream = new FileInputStream(filePath);
		InputStreamReader reader = new InputStreamReader(inStream);
		BufferedReader in = new BufferedReader(reader);
		
		String returnString = "";
		while(in.ready()) {
			returnString += in.readLine() + "\n";
		}
		in.close();
		return returnString;
	}
}
