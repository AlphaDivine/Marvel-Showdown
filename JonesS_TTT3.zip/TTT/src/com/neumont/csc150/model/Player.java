package com.neumont.csc150.model;

public class Player {

	private String name;
	
	public Player() {}
	
	public Player(String name) {
		this.setName(name);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public String toString() {
		return this.getName();
	}
	
	@Override
	public boolean equals(Object obj) {
		if(!(obj instanceof Player)) {
			return false;
		}
		Player other = (Player) obj;
		return this.getName() == other.getName();
	}
	
	public int compareTo(Player o) {
		Player other = (Player) o;
		return this.getName().compareTo(other.getName());
	}
}
