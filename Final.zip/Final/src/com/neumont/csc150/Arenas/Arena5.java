package com.neumont.csc150.Arenas;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Arena5 {
	JPanel j = new JPanel();
	JFrame window = new JFrame();
	JLabel img1 = new JLabel();

	public void populateFrame(JPanel panel) {

		window.getContentPane().add(j);
		j.setBackground(Color.WHITE);
		j.setLayout(new BorderLayout());
		window.setTitle("Marvel Showdown");
		window.setSize(1920, 1080);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		img1.setIcon(new ImageIcon("imageArena5.png"));
		j.add(img1, BorderLayout.CENTER);
		window.setVisible(true);
		window.pack();
		j.add(img1, BorderLayout.CENTER);

	}

	public Arena5() {
		populateFrame(j);
	}

	public static void main(String[] a) {
		Arena5 l = new Arena5();
	}
}
