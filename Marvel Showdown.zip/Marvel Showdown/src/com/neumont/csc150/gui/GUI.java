package com.neumont.csc150.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class GUI implements ActionListener, KeyListener{
	JFrame frame = new JFrame("Marvel Showdown");
	//JPanel Panel = new JPanel();
	JPanel mainPanel;
	JLabel picture = new JLabel();
	private boolean showTitleScreen = false;
	private boolean playing = false;

	public static void main(String[] args) {
		GUI gui = new GUI();


	}
	private void populateFrame(JFrame frame){
		mainPanel = new JPanel() {
			@Override
			public void paint(Graphics g) {
				super.paint(g);
				g.setColor(Color.white);
				g.setFont(new Font(Font.DIALOG, Font.BOLD,50));
				g.drawString("Press the spacebar to play", 650, 1000);
				
			}
		};
		frame.getContentPane().add(mainPanel);
		mainPanel.setBackground(Color.white);
		mainPanel.setLayout(new BorderLayout());
		frame.setTitle("Marvel Showdown!");
		//frame.setVisible(true);
		frame.setSize(1920,1080);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		picture.setIcon(new ImageIcon("C:\\Users\\Quentin Clayton\\Pictures\\Marvel Showdown Menu.png"));
		mainPanel.add(picture, BorderLayout.CENTER);
		frame.setVisible(true);
		mainPanel.repaint();
		//frame.add(Panel);
		
		//frame.validate();
//		JButton button = new JButton("Click me");
//		button.setPreferredSize(new Dimension (40,40));
//		mainPanel.add(button,BorderLayout.CENTER);
	}
	
	public GUI() {
		//frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		populateFrame(frame);
		//frame.pack();
		//frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		//frame.setLocationRelativeTo(null);
		//frame.setVisible(true);
		//populateFrame(frame);
	}
	
	
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	
	/*public void paintComponent(Graphics g){
		g.setColor(Color.WHITE);
		
		if(showTitleScreen){
	            g.setFont(new Font(Font.DIALOG, Font.BOLD, 18));

	            g.drawString("Press 'P' to play.", 175, 400);
		}
	}*/
	
	
	
	@Override
	public void keyPressed(KeyEvent e) {
		 if (showTitleScreen) {
	            if (e.getKeyCode() == KeyEvent.VK_SPACE) {
	                showTitleScreen = false;
	                playing = true;
	            }
	        }
		
	}
	@Override
	public void keyReleased(KeyEvent e) {
		
	}
	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
